Rinom Calltune Android branding assets

Copy the contents of this package's app/src/main/res/ folder into:
app/src/main/res/

Then update app/src/main/AndroidManifest.xml:
  android:label="Rinom Calltune"
  android:icon="@mipmap/ic_launcher"
  android:roundIcon="@mipmap/ic_launcher_round"

In MainActivity.kt:
  - Change the heading text from "CallTune" to "Rinom Calltune".
  - Add an ImageView near the top of the root layout using:
      setImageResource(R.drawable.rinom_logo)
    Use adjustViewBounds = true and a sensible maximum height (about 160dp).
  - Keep the existing ScrollView, controls, and call logic unchanged.

Note: These are standard density-specific launcher PNGs plus an in-app logo.
The source logo is a flattened square image, so this package does not create a
separate transparent adaptive-icon foreground.
